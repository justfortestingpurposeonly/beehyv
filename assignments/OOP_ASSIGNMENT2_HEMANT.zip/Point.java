public class Point {
    private double x;
    private double y;
    Point(double x,double y){
        this.x = x;
        this.y = y;
    }
    public void setPoint(double x,double y){
        this.x = x;
        this.y = y;
    }
    public String getPoint(){
        return String.format("(%.1f,%.1f)",x,y);
    }
    public void setX(double x){
        this.x = x;
    }
    public double getX(){
        return this.x;
    }
    public void setY(double x){
        this.y = y;
    }
    public double getY(){
        return this.y;
    }
}
