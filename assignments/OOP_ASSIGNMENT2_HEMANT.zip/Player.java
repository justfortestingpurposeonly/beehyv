import java.util.Scanner;
public class Player {
    private String name;
    public int guess;

    Player(String name){
        this.name=name;
    }

    Scanner input = new Scanner(System.in);
    public void setGuess(){
        System.out.println("Please enter the guess for player "+this.name);
        this.guess = input.nextInt();
    }

    public int getGuess(){
        return this.guess;
    }

}
