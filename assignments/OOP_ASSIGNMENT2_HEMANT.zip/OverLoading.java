public class OverLoading {
    public String result;
    public String value(String name){
        result = "The value of "+name+" can't be determined as "+name+" is a person.";
        return result;
    }

    public String value(int value){
        result = "The value of orange is "+value+" per kg.";
        return result;
    }

    public static void main(String[] args) {
        OverLoading test1 = new OverLoading();
        OverLoading test2 = new OverLoading();
        System.out.println(test1.value("Hemant"));
        System.out.println(test2.value(50));
    }
}
