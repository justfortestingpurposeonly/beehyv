public class OverRiding extends OverLoading {
    public String value(String name){
        result = "OverRidden method executed....Samajh me aaya kya?"+name;
        return result;
    }
    public static void main(String[] args) {
        OverLoading overRide = new OverRiding();
        System.out.println(overRide.value("BHAI"));
    }
}
