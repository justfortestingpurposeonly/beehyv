import java.util.Random;
public class GuessGame {
    public String player1;
    public String player2;
    public String player3;
    public String result1;
    public String result2;
    public String result3;
    public String result;
    public String rightGuess;

    Random rand = new Random();
    public int random = rand.nextInt(9);

    public String startGame(){
        Player player1 = new Player("player1");
        player1.setGuess();
        Player player2 = new Player("player2");
        player2.setGuess();
        Player player3 = new Player("player3");
        player3.setGuess();

        if(random == player1.getGuess())
            result1 = "The guess of player1 is right";
        else
            result1 = "The guess of player1 is wrong";
        if(random == player2.getGuess())
            result2 = "The guess of player2 is right";
        else
            result2 = "The guess of player2 is wrong";
        if(random == player3.getGuess())
            result3 = "The guess of player3 is right";
        else
            result3 = "The guess of player3 is wrong";

        rightGuess = "The correct random value was "+random;

        result = result1+"\n" + result2 + "\n" + result3 + "\n"+rightGuess;
        return result;
    }


}
